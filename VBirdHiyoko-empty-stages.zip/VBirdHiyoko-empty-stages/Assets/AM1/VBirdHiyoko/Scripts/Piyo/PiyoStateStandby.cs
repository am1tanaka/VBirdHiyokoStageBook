using AM1.State;

namespace AM1.VBirdHiyoko
{
    /// <summary>
    /// 待機状態。次のステージへ移行する時などの何もしない状態。
    /// </summary>
    public class PiyoStateStandby : AM1StateQueueBase
    {
    }
}
