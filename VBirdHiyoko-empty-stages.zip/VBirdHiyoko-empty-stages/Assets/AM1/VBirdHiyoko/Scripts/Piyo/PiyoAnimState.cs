namespace AM1.VBirdHiyoko
{
    /// <summary>
    /// ぴよのAnimatorのパラメーターの値
    /// </summary>
    public enum PiyoAnimState
    {
        Stand,
        Walk,
        Push,
        Turn,
        Banzai,
    }
}