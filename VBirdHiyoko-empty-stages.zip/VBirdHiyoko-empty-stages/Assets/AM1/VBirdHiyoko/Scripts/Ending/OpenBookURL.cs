using UnityEngine;

namespace AM1.VBirdHiyoko
{
    public class OpenBookURL : MonoBehaviour
    {
        public void OpenURL()
        {
            SEPlayer.Play(SEPlayer.SE.Click);
            Application.OpenURL("https://github.com/am1tanaka/VBirdHiyoko");
        }
    }
}